# Windows-RDP-ACTIONS



### Option 1 (Easiest way 🚑- No sound) 

1) Go https://remotedesktop.google.com/headless and login if needed.
2) Copy Powershell command that page.
3) Go actions tab in your forked repo.
4) Select `Chrome Remote Desktop`
5) Trigger action with your desired 6 digit pin and paste command in step 1.
6) Go again step 1 link in remote Support tab.
7) When setup finished , you can see the machine in list , write your pin and connect.
8) Enjoy! ☕
9) When you're done introspecting, cancel the job.


